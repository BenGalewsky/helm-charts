# Probe Design Helm Chart

This Helm chart deploys the Probe Design web application on a Kubernetes cluster.

## Prerequisites

- Kubernetes 1.19+
- Helm 3.0+
- PersistentVolume provisioner support in the underlying infrastructure (if persistence is enabled)

## Installing the Chart

To install the chart with the release name `probe-design`:

```bash
helm install probe-design ./helm/probe-design
```

To install with custom values:

```bash
helm install probe-design ./helm/probe-design -f custom-values.yaml
```

## Uninstalling the Chart

To uninstall/delete the `probe-design` deployment:

```bash
helm uninstall probe-design
```

## Configuration

The following table lists the configurable parameters of the Probe Design chart and their default values.

| Parameter | Description | Default |
|-----------|-------------|---------|
| `replicaCount` | Number of replicas | `1` |
| `image.repository` | Image repository | `bengal1/probe-design` |
| `image.tag` | Image tag | `main` |
| `image.pullPolicy` | Image pull policy | `IfNotPresent` |
| `service.type` | Kubernetes service type | `ClusterIP` |
| `service.port` | Service port | `8000` |
| `ingress.enabled` | Enable ingress | `false` |
| `ingress.className` | Ingress class name | `""` |
| `ingress.hosts` | Ingress hosts configuration | See values.yaml |
| `django.debug` | Django DEBUG setting | `"0"` |
| `django.secretKey` | Django SECRET_KEY | `"change-me-in-production"` |
| `django.allowedHosts` | Django ALLOWED_HOSTS | `"*"` |
| `persistence.enabled` | Enable persistence | `true` |
| `persistence.staticVolume.size` | Static files volume size | `1Gi` |
| `persistence.mediaVolume.size` | Media files volume size | `5Gi` |
| `resources.limits.cpu` | CPU limit | `1000m` |
| `resources.limits.memory` | Memory limit | `2Gi` |

## Examples

### Basic Installation

```bash
helm install probe-design ./helm/probe-design
```

### Installation with Ingress

Create a `values-ingress.yaml` file:

```yaml
ingress:
  enabled: true
  className: nginx
  annotations:
    cert-manager.io/cluster-issuer: letsencrypt-prod
  hosts:
    - host: probe-design.example.com
      paths:
        - path: /
          pathType: Prefix
  tls:
    - secretName: probe-design-tls
      hosts:
        - probe-design.example.com
```

Install with:

```bash
helm install probe-design ./helm/probe-design -f values-ingress.yaml
```

### Production Installation

Create a `values-prod.yaml` file:

```yaml
replicaCount: 3

django:
  debug: "0"
  secretKey: "your-very-secret-key-here"
  allowedHosts: "probe-design.example.com"

resources:
  limits:
    cpu: 2000m
    memory: 4Gi
  requests:
    cpu: 1000m
    memory: 2Gi

persistence:
  staticVolume:
    size: 5Gi
  mediaVolume:
    size: 20Gi

autoscaling:
  enabled: true
  minReplicas: 3
  maxReplicas: 10
  targetCPUUtilizationPercentage: 70
```

Install with:

```bash
helm install probe-design ./helm/probe-design -f values-prod.yaml
```

## Accessing the Application

After installation, follow the instructions in the NOTES output to access your application.

For ClusterIP service type, use port-forwarding:

```bash
kubectl port-forward svc/probe-design 8000:8000
```

Then visit http://localhost:8000

## Persistence

The chart creates two PersistentVolumeClaims:
- `probe-design-static`: For Django static files
- `probe-design-media`: For user-uploaded media files

To use a specific storage class:

```yaml
persistence:
  staticVolume:
    storageClass: "fast-ssd"
  mediaVolume:
    storageClass: "standard"
```

## Security Considerations

1. Always change the `django.secretKey` in production
2. Set appropriate `django.allowedHosts` values
3. Enable TLS/SSL for ingress in production
4. Review and adjust security contexts as needed
5. Consider using Kubernetes secrets for sensitive values

## Troubleshooting

Check pod status:
```bash
kubectl get pods -l app.kubernetes.io/name=probe-design
```

View logs:
```bash
kubectl logs -l app.kubernetes.io/name=probe-design -f
```

Describe deployment:
```bash
kubectl describe deployment probe-design
```

## Upgrading

To upgrade an existing release:

```bash
helm upgrade probe-design ./helm/probe-design -f custom-values.yaml
```
